# *** Note: Since I am quite busy atm, I will not be contributing to this repo in the forseeable future. Please feel free to clone the repo and improve upon it if required. ***

# Web-Browser-using-tkinter-and-python
The web browser is implemented with GUI in tkinter and which gets the desired information from the server.
